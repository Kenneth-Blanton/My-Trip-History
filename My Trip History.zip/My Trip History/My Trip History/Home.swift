//
//  Home.swift
//  My Trip History
//
//  Created by Kenneth Blanton on 12/16/21.
//

import SwiftUI

struct Home: View {
    var body: some View {
        NavigationView{
            ZStack{
                Color.green.ignoresSafeArea(.all)
                VStack{
                    Text("Click on a destination below")
                        .fontWeight(.bold)
                        .foregroundColor(.yellow)
                        .background(Color.black.frame(width: 390, height: 30))
                        .padding(.bottom, 30)
                NavigationLink("Miami - March 2021",
                               destination: Miami())
                    .frame(width: 360, height: 20, alignment: .center)
                    .foregroundColor(.cyan)
                    .background(Color.black.frame(width: 160))
                    .padding(.horizontal, 175)
                    .padding(.bottom, 5)
                    
                NavigationLink("San Fran - May 2021",
                               destination: SanFran1())
                .frame(width: 360, height: 20, alignment: .center)
                .foregroundColor(.yellow)
                .background(Color.black.frame(width: 165))
                .padding(.horizontal, 175)
                .padding(.bottom, 5)
                    
                NavigationLink("San Fran - August 2021",
                               destination: SanFran2())
                .frame(width: 360, height: 20, alignment: .center)
                .foregroundColor(.yellow)
                .background(Color.black.frame(width: 185))
                .padding(.horizontal, 175)
                .padding(.bottom, 5)
                    
                Spacer()
                    
                    Text("Thank you for viewing my app!")
                        .fontWeight(.bold)
                        .foregroundColor(.yellow)
                        .background(Color.black.frame(width: 390, height: 30))
                        .padding(.bottom, 5)
                    
                    Text("Made by Kenneth Blanton")
                        .padding(.bottom, 50)
                }
                    .navigationTitle("My Vacation History")
        }
        }
    }
}

struct Miami: View{
    let pictures = ["Miami 1", "Miami 2", "Miami 3", "Miami 4", "Miami 5", "Miami 6"]
    let captions = ["This is an Ecuadorian dish", "This is a Painting at the Art Museum", "This is a Painting at the Art Museum", "A View of the Water from Miami Beach", "This is me in the Brickell City Centre", "This is me at the Miami Zoo"]
    @State var picture = ""
    @State var caption = ""
    @State var picNum = 0
    @State var capNum = 0
    let picMax = 5
    let picMin = 0
    let capMax = 5
    let capMin = 0
    
    var body: some View{
        ZStack{
            Color.cyan.ignoresSafeArea(.all)
            ZStack{
                Rectangle()
                    .frame(height: 520)
                    .padding(.bottom, 90)
                    .shadow(color: .white, radius: 400)
                    .foregroundColor(.white)
                Image(pictures[picNum])
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(height: 520)
                    .padding(.bottom, 90)
                VStack{
                    Text("Miami Trip May 2021")
                        .fontWeight(.heavy)
                        .frame(width: 390, height: 10, alignment: .center)
                        .foregroundColor(.black)
                        .padding(.vertical, 11)
                        .background(Color.pink.frame(width: 390, height: 30))
                        .padding(.top, -80)
                    Text(captions[capNum])
                        .font(.footnote)
                        .fontWeight(.bold)
                        .frame(width: 300, height: 10, alignment: .center)
                        .foregroundColor(Color.black)
                        .padding(.horizontal, 110)
                        .padding(.vertical, 10)
                        .background(Color.pink)
                        .shadow(color: Color.white, radius: 400)
                        .padding(.bottom, 5)
                        .padding(.top, 480)
                    HStack(){
                        Button(action: {
                            picture = pictures[picNum]
                            picNum -= 1
                            if (picNum < picMin){
                                picNum = picMax
                            }
                            caption = captions[capNum]
                            capNum -= 1
                            if (capNum < capMin){
                                capNum = capMax
                            }
                        
                    }, label: {
                        Image(systemName: "arrow.backward")
                            .foregroundColor(Color.black)
                        Text("Previous")
                            .font(.body)
                            .fontWeight(.bold)
                            .foregroundColor(Color.black)
                            .padding(.horizontal, 20)
                            .background(Color.pink
                                            .cornerRadius(10)
                                            .shadow(radius: 3)
                            )
                            
                    })
                            .padding(.trailing, 120)
                            .padding(.leading, -90)
                        Button(action: {
                            picture = pictures[picNum]
                            picNum += 1
                            if (picNum > picMax){
                                picNum = picMin
                            }
                            caption = captions[capNum]
                            capNum += 1
                            if (capNum > capMax){
                                capNum = capMin
                            }
                            
                        }, label: {
                            Text("Next")
                                .font(.body)
                                .fontWeight(.bold)
                                .foregroundColor(Color.black)
                                .padding(.horizontal, 20)
                                .background(Color.pink
                                                .cornerRadius(10)
                                                .shadow(radius: 3)
                                )
                            Image(systemName: "arrow.forward")
                                .foregroundColor(Color.black)
                        })
                            .padding(.trailing, -75)
                    }
                }
            }
        }
    }
}


struct SanFran1: View{
    let pictures = ["San Fran 1", "San Fran 2", "San Fran 3"]
    let captions = ["This is me on Market Street", "This is me at the Golden Gate Bridge", "This is me after a dinner at Lolinda"]
    @State var picture = ""
    @State var caption = ""
    @State var picNum = 0
    @State var capNum = 0
    let picMax = 2
    let picMin = 0
    let capMax = 2
    let capMin = 0

    var body: some View{
        ZStack{
            Color.yellow.ignoresSafeArea(.all)
            Rectangle()
                .frame(height: 520)
                .padding(.bottom, 90)
                .shadow(color: .white, radius: 400)
            Image(pictures[picNum])
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(height: 520)
                .padding(.bottom, 90)
            VStack{
                Text("San Francisco Trip May 2021")
                    .fontWeight(.bold)
                    .frame(width: 390, height: 10, alignment: .center)
                    .foregroundColor(.white)
                    .padding(.vertical, 11)
                    .background(Color.black.frame(width: 390, height: 30))
                    .padding(.top, -80)
                Text(captions[capNum])
                    .font(.footnote)
                    .fontWeight(.bold)
                    .frame(width: 300, height: 10, alignment: .center)
                    .foregroundColor(Color.white)
                    .padding(.horizontal, 110)
                    .padding(.vertical, 10)
                    .background(Color.black)
                    .shadow(color: Color.white, radius: 400)
                    .padding(.bottom, 5)
                    .padding(.top, 480)
                HStack(){
                    Button(action: {
                        picture = pictures[picNum]
                        picNum -= 1
                        if (picNum < picMin){
                            picNum = picMax
                        }
                        caption = captions[capNum]
                        capNum -= 1
                        if (capNum < capMin){
                            capNum = capMax
                        }
                    
                }, label: {
                    Image(systemName: "arrow.backward")
                        .foregroundColor(Color.black)
                    Text("Previous")
                        .font(.body)
                        .fontWeight(.bold)
                        .foregroundColor(Color.black)
                        .padding(.horizontal, 20)
                        .background(Color.orange
                                        .cornerRadius(10)
                                        .shadow(radius: 3)
                        )
                        
                })
                        .padding(.trailing, 120)
                        .padding(.leading, -90)
                    Button(action: {
                        picture = pictures[picNum]
                        picNum += 1
                        if (picNum > picMax){
                            picNum = picMin
                        }
                        caption = captions[capNum]
                        capNum += 1
                        if (capNum > capMax){
                            capNum = capMin
                        }
                        
                    }, label: {
                        Text("Next")
                            .font(.body)
                            .fontWeight(.bold)
                            .foregroundColor(Color.black)
                            .padding(.horizontal, 20)
                            .background(Color.orange
                                            .cornerRadius(10)
                                            .shadow(radius: 3)
                            )
                        Image(systemName: "arrow.forward")
                            .foregroundColor(Color.black)
                    })
                        .padding(.trailing, -75)
                }
            }
        }
    }
}

        
struct SanFran2: View {
    let pictures = ["San Fran Me 1", "San Fran Me 2", "San Fran Me 3"]
    let captions = ["This is me in Lafayette Park", "This is The Mission District", "This is the court house in San Francisco"]
    @State var picture = ""
    @State var caption = ""
    @State var picNum = 0
    @State var capNum = 0
    let picMax = 2
    let picMin = 0
    let capMax = 2
    let capMin = 0
    
    var body: some View{
        ZStack{
            Color.yellow.ignoresSafeArea(.all)
            Rectangle()
                .frame(height: 520)
                .padding(.bottom, 90)
                .shadow(color: .white, radius: 400)
            Image(pictures[picNum])
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(height: 520)
                .padding(.bottom, 90)
            VStack{
                Text("San Francisco Trip August 2021")
                    .fontWeight(.bold)
                    .frame(width: 390, height: 10, alignment: .center)
                    .foregroundColor(.white)
                    .padding(.vertical, 11)
                    .background(Color.black.frame(width: 390, height: 30))
                    .padding(.top, -80)
                Text(captions[capNum])
                    .font(.footnote)
                    .fontWeight(.bold)
                    .frame(width: 300, height: 10, alignment: .center)
                    .foregroundColor(Color.white)
                    .padding(.horizontal, 110)
                    .padding(.vertical, 10)
                    .background(Color.black)
                    .shadow(color: Color.white, radius: 400)
                    .padding(.bottom, 5)
                    .padding(.top, 480)
                HStack(){
                    Button(action: {
                        picture = pictures[picNum]
                        picNum -= 1
                        if (picNum < picMin){
                            picNum = picMax
                        }
                        caption = captions[capNum]
                        capNum -= 1
                        if (capNum < capMin){
                            capNum = capMax
                        }
                    
                }, label: {
                    Image(systemName: "arrow.backward")
                        .foregroundColor(Color.black)
                    Text("Previous")
                        .font(.body)
                        .fontWeight(.bold)
                        .foregroundColor(Color.black)
                        .padding(.horizontal, 20)
                        .background(Color.orange
                                        .cornerRadius(10)
                                        .shadow(radius: 3)
                        )
                        
                })
                        .padding(.trailing, 120)
                        .padding(.leading, -90)
                    Button(action: {
                        picture = pictures[picNum]
                        picNum += 1
                        if (picNum > picMax){
                            picNum = picMin
                        }
                        caption = captions[capNum]
                        capNum += 1
                        if (capNum > capMax){
                            capNum = capMin
                        }
                        
                    }, label: {
                        Text("Next")
                            .font(.body)
                            .fontWeight(.bold)
                            .foregroundColor(Color.black)
                            .padding(.horizontal, 20)
                            .background(Color.orange
                                            .cornerRadius(10)
                                            .shadow(radius: 3)
                            )
                        Image(systemName: "arrow.forward")
                            .foregroundColor(Color.black)
                    })
                        .padding(.trailing, -75)
                }
            }
        }
    }
}






    
struct Home_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            Home()
        }
    }
}


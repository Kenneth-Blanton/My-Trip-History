//
//  My_Trip_HistoryApp.swift
//  My Trip History
//
//  Created by Kenneth Blanton on 12/16/21.
//

import SwiftUI

@main
struct My_Trip_HistoryApp: App {
    var body: some Scene {
        WindowGroup {
            Home()
        }
    }
}
